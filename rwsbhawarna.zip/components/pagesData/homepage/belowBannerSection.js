import React from 'react';
const BelowBannerSection = () => {
  return (
    // <BelowBannerSectionWrapper>
    //   <SchoolBells>
    //     <SchoolBellsList>
    //       <SchoolBellsListItem>School bells are ringing loud and clear, vacation over, school is here</SchoolBellsListItem>
    //       <SchoolBellsListItem>School bells are ringing loud and clear, vacation over, school is here</SchoolBellsListItem>
    //       <SchoolBellsListItem>School bells are ringing loud and clear, vacation over, school is here</SchoolBellsListItem>
    //       <SchoolBellsListItem>School bells are ringing loud and clear, vacation over, school is here</SchoolBellsListItem>
    //       <SchoolBellsListItem>School bells are ringing loud and clear, vacation over, school is here</SchoolBellsListItem>
    //       <SchoolBellsListItem>School bells are ringing loud and clear, vacation over, school is here</SchoolBellsListItem>
    //     </SchoolBellsList>
    //   </SchoolBells>
    // </BelowBannerSectionWrapper>

<></>


  );
};

export default BelowBannerSection;