import BritishStyle from './bristish.module.css'

const BritishCouncilSection = () => {
    return (
        <section className={BritishStyle.british_sec}>
            <div className="container">

            </div>
        </section>
    );
};

export default BritishCouncilSection;